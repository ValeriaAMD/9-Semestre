from operaciones.suma import operacion
import unittest

class Testcalculadora(unittest.TestCase):

    def test_suma_v8_num_enteros(self):
        a = 22
        b = 11
        sum = a + b
        result = operacion("8","0","22","11")
        self.assertEquals(sum,result)
    def test_suma_v7_num_enteros(self):
        a = 22
        b = 11
        sum = a + b
        result = operacion("7","0","22","11")
        self.assertEquals(sum,result)

if __name__ == '__main__':
    unittest.main()